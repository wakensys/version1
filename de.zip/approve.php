<?
include "conf/config.php";
if (!$_SESSION['memberid']) {
	header("Location: ".SITEURL."login.php?approve=1");
	exit;
}

if ($_REQUEST['cmd']=="set_ordertype") {
	
	$need=getWhere("order_types","need_address","order_type='".safe($_REQUEST['val'])."'");
	if ($need==1) {
		echo "<script>$('.tr_delivery').show();</script>";
	} else {
		echo "<script>$('.tr_delivery').hide();</script>";
	}
	
	exit;
}

$rest_id=getWhere("cart","rest_id","session_id='".session_id()."'");
$rsr=getSqlRow("SELECT paymenttypes,rest_tax,servicefee FROM rests WHERE id=".$rest_id."");

$rest_tax=$rsr['rest_tax'];
$service_fee=$rsr['servicefee'];

$getRss= mysql_query("SELECT * FROM cart where session_id='".session_id()."' and rest_id=".$rest_id." order by added_date asc");
while ($rss = mysql_fetch_array($getRss)) {
	$rsp=getSqlRow("select * from products where id=".$rss['prod_id']."");
	$extras_array=explode(",",$rss['extras']);
	$price=($rsp['proprice']>0)?$rsp['proprice']:$rsp['price'];
	$price=($price*$rss['qty']);
	$price=number_format($price,2,".","");
	$sub_total=$sub_total+$price;	
	$getRsss = mysql_query("SELECT optionals.* FROM optionals,optional_product where optional_product.prodid=".$rsp['id']." and optional_product.optid=optionals.id order by optional asc");
	while ($rsss = @mysql_fetch_array($getRsss)) {
		if (in_array($rsss['id'],$extras_array)) $extra_total=$extra_total+($rsss['price']*$rss['qty']);
	}
	
	
	
}
if ($rest_tax>0) { 
	$tax_total=number_format(($sub_total+$extra_total)*$rest_tax/100,2,".","");	
}
$order_total=$tax_total+$sub_total+$service_fee+$extra_total;


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title><?=$GLOBALS['order_approve']?> - <?=SITENAME?></title>
<? include "inc/styles.php"; ?>
<link rel="stylesheet" href="js/jqueryui/themes/base/jquery.ui.all.css" /> 
<script src="js/jqueryui/ui/jquery.ui.core.js"></script> 
<script src="js/jqueryui/ui/jquery.ui.widget.js"></script> 
<script src="js/jqueryui/ui/jquery.ui.datepicker.js"></script> 
<script>
$(function() {
	$( "#deliverydate" ).datepicker();
});

function setAddress(id) {
	$("#span_address_loading").show();
	$("#result").load("conf/post.php?cmd=set_address&id="+id);
}

function setOrderType(val) {
	
	$.post("<?=$_SERVER['PHP_SELF']?>", { cmd: "set_ordertype", val: val }, 
            function(data) {
			$("#result").html(data);
	});
	return false;
	
}

function showcc(val) {
	if (val=="Online Credit Card" || val=="Authorize.net") {
		$(".cc_details").show();
	} else {
		$(".cc_details").hide();
	}
}
</script>
</head>
<body>

<div class="mainbody">

<? include "inc/header.php"; ?>
                

<div id="content" class="container_12">
<div class="grid_12">
<h2><?=$GLOBALS['order_approve']?></h2>
<div id="div_order">
<?=$GLOBALS['order_approve_notice']?>


<form name="myform" id="myform" action="javascript:void(0);">
<input type="hidden" name="cmd" id="cmd" value="approve_order" />
<input type="hidden" name="order_total" id="order_total" value="<?=$order_total?>" />
<table style="width:600px;margin-top:10px;line-height:28px;">

<tr>
<td style="width:150px;"><?=$GLOBALS['order_type']?></td>
<td><select name="order_type" id="order_type" style="width:200px;" onchange="setOrderType(this.value)">
<?
$getRss= mysql_query("SELECT * FROM order_types order by need_address desc,order_type asc");
while ($rss = mysql_fetch_array($getRss)) {
?>
<option value="<?=$rss['order_type']?>"><?=$rss['order_type']?></option>
<? } ?>
</select></td>
</tr>

<tr>
<td><?=$GLOBALS['payment_type']?></td>
<td><select name="paymenttype" id="paymenttype" style="width:200px;" onchange="showcc(this.value);">
<option value=""><?=$GLOBALS['please_select']?></option>
<? 
$payment_types=explode("|",$rsr['paymenttypes']);
foreach ($payment_types as $key=>$val) {
?>
<option value="<?=$val;?>"><?=$val;?></option>
<? } ?>
</select></td>
</tr>

<tr class="tr_delivery">
<td><?=$GLOBALS['delivery_date']?></td>
<td><input type="text" name="deliverydate" id="deliverydate" value="<?=Date(DELIVERY_DATE_FORMAT)?>" style="width:70px;" class="input-text" /> - <input type="text" name="deliverytime" id="deliverytime" value="<?=Date("H:i")?>" style="width:40px;text-align:center;" class="input-text" /></td>
</tr>


<tr class="cc_details" style="display:none;">
<td colspan="2" style="font-weight:bold;"><?=$GLOBALS['cc_details']?></td>
</tr>


  <tr class="cc_details" style="display:none;">
    <td>Card Type</td>
    <td><select name="cc_type" id="cc_type">
    <option value="Amex">Amex</option>
    <option value="MasterCard">MasterCard</option>
    <option value="Visa">Visa</option>
	</select>
	</td>
  </tr>
  <tr class="cc_details" style="display:none;">
    <td>Card Holder Name</td>
    <td><input type="text" name="cc_name" id="cc_name" value="" maxlength="100" style="width:260px;"  /></td>
  </tr>
  <tr class="cc_details" style="display:none;">
    <td>Card Holder Lastname</td>
    <td><input type="text" name="cc_lastname" id="cc_lastname" value="" maxlength="100" style="width:260px;"  /></td>
  </tr>
 <tr class="cc_details" style="display:none;">
    <td>Card No</td>
    <td><input type="text" name="cc_no" id="cc_no" value="" maxlength="20" style="width:160px;"  onkeyup='this.value=this.value.replace(/[^\d]*/gi,"");' /></td>
  </tr>
  <tr class="cc_details" style="display:none;">
    <td>Card Expiry</td>
    <td><select name="expmonth" style="width: 50px;">
								<option value="01">01</option>
								<option value="02">02</option>
								<option value="03">03</option>
								<option value="04">04</option>
								<option value="05">05</option>
								<option value="06">06</option>
								<option value="07">07</option>
								<option value="08">08</option>
								<option value="09">09</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								</select>
	<select name="expyear" style="width: 70px;">
   <?
                $yil = date("Y");
                for ($i = 0; $i <= 10; $i++)
                {
                    $yiln = $yil + $i;
                    //$yilnn = substr($yiln, -2);
                    $yilnn =$yiln;
                    echo "<option value=\"$yilnn\" " . (($yilnn == $_POST['expyear']) ? "selected":
                        "") . ">$yiln</option> \n";
                }
?>
</select></td>
  </tr>
  <tr class="cc_details" style="display:none;">
    <td>Card CVV2</td>
    <td><input type="text" name="cc_cvv2" id="cc_cvv2" value="" maxlength="4" style="width:50px;"  onkeyup='this.value=this.value.replace(/[^\d]*/gi,"");' /></td>
  </tr>

<tr class="tr_delivery">
<td colspan="2" style="font-weight:bold;"><?=$GLOBALS['delivery_address']?></td>
</tr>

<tr class="tr_delivery">
<td style="width:150px;"><?=$GLOBALS['addresses']?></td>
<td style="height:30px;"><select name="address_id" id="address_id" style="width:200px;" onchange="setAddress(this.value);">
<option value=""><?=$GLOBALS['new_address']?></option>
<?
$getRss= mysql_query("SELECT * FROM delivery_addresses where userid=".$_SESSION['memberid']." order by nick asc");
while ($rss = mysql_fetch_array($getRss)) {
?>
<option value="<?=$rss['id']?>"><?=$rss['nick']?></option>
<? } ?>
</select> <span id="span_address_loading" style="display:none;"><img src="img/loading.gif"  /></span></td>
</tr>


<tr class="tr_delivery">
<td><?=$GLOBALS['address_nick']?></td>
<td><input type="text" name="nick" id="nick" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['name']?></td>
<td><input type="text" name="name" id="name" value="" style="width:300px;" maxlength="100" class="input-text" /></td>
</tr>

<tr class="tr_delivery">
<td style="vertical-align:top;"><?=$GLOBALS['address']?></td>
<td><textarea name="address" id="address" style="width:400px;height:70px;"></textarea></td>
</tr>



<tr class="tr_delivery">
<td><?=$GLOBALS['city']?></td>
<td><select name="city" id="city" style="width:200px;" >
	<option value="">---</option>
	<? 
	$getRss = mysql_query("SELECT id,city,region FROM delivery_areas group by city");
	while ($rss = mysql_fetch_array($getRss)) { ?>
	<option value="<?=$rss['city'];?>"><?=$rss['city'];?> <? if ($rss['region']) echo " (".$rss['region'].")"; ?></option>
	<? } 
	?>
	</select></td>
</tr>

<tr class="tr_delivery">
<td><?=$GLOBALS['postcode']?></td>
<td><input type="text" name="postcode" id="postcode" value="" style="width:100px;" maxlength="10" onkeyup='this.value=this.value.replace(/[^\d]*/gi,"");'  class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['phone']?></td>
<td><input type="text" name="phone" id="phone" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['mobilphone']?></td>
<td><input type="text" name="mobilphone" id="mobilphone" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['company']?></td>
<td><input type="text" name="company" id="company" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td style="vertical-align:top;"><?=$GLOBALS['order_note']?></td>
<td><textarea name="order_note" id="order_note" style="width:400px;height:70px;"></textarea></td>
</tr>


<tr>
<td></td>
<td style="height:30px;"><input name="sbt" id="sbt" type="submit" value="<?=$GLOBALS['approve_my_order']?>" onclick='this.disabled=true; post("myform"); return false;'  /> <span id="span_loading"></span></td>
</tr>


</table>

</form>

</div>
</div>
</div>
            

<? include "inc/footer.php"; ?>
            
<div class="clearfix"></div>
</div>

</body>
</html>
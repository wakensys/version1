<?
include "conf/config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title><?=SITENAME?> - <?=$GLOBALS['contact']?></title>
<? include "inc/styles.php"; ?>
</head>
<body>

<div class="mainbody">

<? include "inc/header.php"; ?>
                

<div id="content" class="container_12">
<div class="grid_12">
<h2><?=$GLOBALS['contact']?></h2>
<div>


<form id="myform" name="myform" method="post" action="javascript:void(null);">
  <input type="hidden" name="cmd" id="cmd" value="send_contact" />
 <table>
  <tr>
 <td width="100" height="30"><?=$GLOBALS['email']?></td>
 <td><input type="text" name="email" id="email" maxlength="100" style="width:400px;" class="input-text" /></td>
 </tr>
 <tr>
 <td width="100" height="30"><?=$GLOBALS['subject']?></td>
 <td><input type="text" name="subject" id="subject" maxlength="100" style="width:400px;" class="input-text" /></td>
 </tr>
  <tr>
 <td width="100" style="vertical-align:top;"><?=$GLOBALS['message']?></td>
 <td><textarea name="message" id="message" style="width:400px;height:200px;" class="input-text"></textarea></td>
 </tr>
 
  <tr>
 <td width="100" height="30"></td>
 <td><input name="sbt" id="sbt" type="submit" value="<?=$GLOBALS['send']?>"  onclick='this.disabled=true; post("myform"); return false;' /> <span id="span_loading"></span></td>
 </tr>
 
 </table>
 
 
 </form>

</div>
</div>
</div>
            

<? include "inc/footer.php"; ?>
            
<div class="clearfix"></div>
</div>

</body>
</html>
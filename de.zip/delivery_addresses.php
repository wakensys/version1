<?
include "conf/config.php";
checkLogin();
$rs=getSqlRow("select * from users where id=".$_SESSION['memberid']."");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title><?=$GLOBALS['delivery_addresses']?> - <?=SITENAME?></title>
<? include "inc/styles.php"; ?>
<script>
function setAddress(id) {
	$("#span_address_loading").show();
	$("#result").load("conf/post.php?cmd=set_address&id="+id);
}
</script>
</head>
<body>

<div class="mainbody">

<? include "inc/header.php"; ?>
                

<div id="content" class="container_12">
<div class="grid_12">
<h2><?=$GLOBALS['delivery_addresses']?></h2>
<div>


<form id="myform" name="myform" method="post" action="javascript:void(null);">
  <input type="hidden" name="cmd" id="cmd" value="save_address" />
<table class="fonrm_table">

<tr>
<td style="width:150px;"><?=$GLOBALS['addresses']?></td>
<td style="height:30px;"><select name="address_id" id="address_id" style="width:200px;" onchange="setAddress(this.value);">
<option value=""><?=$GLOBALS['new_address']?></option>
<?
$getRss= mysql_query("SELECT * FROM delivery_addresses where userid=".$_SESSION['memberid']." order by nick asc");
while ($rss = mysql_fetch_array($getRss)) {
?>
<option value="<?=$rss['id']?>"><?=$rss['nick']?></option>
<? } ?>
</select> <span id="span_address_loading" style="display:none;"><img src="img/loading.gif"  /></span></td>
</tr>


<tr>
<td><?=$GLOBALS['address_nick']?></td>
<td><input type="text" name="nick" id="nick" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['name']?></td>
<td><input type="text" name="name" id="name" value="" style="width:300px;" maxlength="100" class="input-text" /></td>
</tr>

<tr>
<td style="vertical-align:top;"><?=$GLOBALS['address']?></td>
<td><textarea name="address" id="address" style="width:400px;height:70px;"></textarea></td>
</tr>



<tr>
<td><?=$GLOBALS['city']?></td>
<td><select name="city" id="city" style="width:200px;" >
	<option value="">---</option>
	<? 
	$getRss = mysql_query("SELECT id,city,region FROM delivery_areas group by city");
	while ($rss = mysql_fetch_array($getRss)) { ?>
	<option value="<?=$rss['city'];?>"><?=$rss['city'];?> <? if ($rss['region']) echo " (".$rss['region'].")"; ?></option>
	<? } 
	?>
	</select></td>
</tr>

<tr>
<td><?=$GLOBALS['postcode']?></td>
<td><input type="text" name="postcode" id="postcode" value="" style="width:100px;" maxlength="10" onkeyup='this.value=this.value.replace(/[^\d]*/gi,"");' class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['phone']?></td>
<td><input type="text" name="phone" id="phone" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['mobilphone']?></td>
<td><input type="text" name="mobilphone" id="mobilphone" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>

<tr>
<td><?=$GLOBALS['company']?></td>
<td><input type="text" name="company" id="company" value="" style="width:200px;" maxlength="50" class="input-text" /></td>
</tr>
  <tr>
 <td ></td>
 <td style="height:30px;"><input name="sbt" id="sbt" type="submit" value="<?=$GLOBALS['save']?>"  onclick='this.disabled=true; post("myform"); return false;' /> <span id="span_loading"></span></td>
 </tr>
 
 </table>
 
 
 </form>

</div>
</div>
</div>
            

<? include "inc/footer.php"; ?>
            
<div class="clearfix"></div>
</div>

</body>
</html>